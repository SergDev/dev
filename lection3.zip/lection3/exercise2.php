<?php

function AllfileSize($allfiles){
    $filesizes = 0;
    foreach ($allfiles as $item) {
        $filesizes += filesize($item);
        echo $item."<br>";
    }
    return $filesizes;
}

$dir1 = scandir("./1/2/");

var_dump($dir1);
foreach ($dir1 as $item){
    if (is_file($item)) {
        $currentDirFile[] = $item;
    }

}

//foreach ()

echo "Размер каталога ".AllfileSize($currentDirFile);


